# FSSAI Food Safety Manual — Prototype Notes

This file is an educational placeholder for a project demo. Replace it with the current official manual and local operating rules before production use.

Food businesses should maintain hygienic handling, prevent cross-contamination, and preserve a documented temperature and time history for prepared food. Safe handling is a chain of controls, not a single AI prediction.

When a critical control is unknown, the responsible action is to escalate to a trained person. The absence of evidence is not evidence that the food is safe.
