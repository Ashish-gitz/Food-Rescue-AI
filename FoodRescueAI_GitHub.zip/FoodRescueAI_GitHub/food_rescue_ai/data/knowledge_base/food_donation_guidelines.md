# Food Donation Guidelines

This prototype knowledge document is a starting point for a local operating procedure, not a substitute for applicable law or a trained food-safety lead.

## Time and temperature

Organizations should record preparation time, storage method, handoff time, and any available temperature checks. Same-day handoff is preferred for prepared food. When the cold chain or timing is uncertain, hold the batch for review rather than relying on an automated clearance.

## Handoff

Use clean, food-safe packaging. Label the food with the item name, preparation time, allergens known to the provider, and the receiving organization's name. Confirm the partner can accept the quantity before dispatch.

## Human verification

An AI recommendation is a triage signal. A trained food-safety lead remains accountable for the final decision, especially when the batch contains high-risk foods, the storage history is incomplete, or local rules differ.
