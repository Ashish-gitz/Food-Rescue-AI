# NGO Donation Guidelines

Receiving partners need accurate quantity, packaging, food type, allergens, preparation time, and pickup window. A partner match is useful only when the receiving organization has capacity and accepts the food category.

Call ahead for large donations. Confirm operating hours, transport responsibility, and whether a temperature log is required. Never disclose personal information about diners, donors, or recipients in a public report.
