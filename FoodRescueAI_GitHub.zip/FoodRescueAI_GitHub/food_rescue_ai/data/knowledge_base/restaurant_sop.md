# Restaurant Surplus SOP

1. Identify the batch and pause service.
2. Record food name, amount, preparation time, storage method, and temperature evidence.
3. Separate food with unknown history.
4. Ask the food-safety lead to review the case.
5. Contact a receiving partner and confirm capacity.
6. Label, package, record the handoff, and preserve the donation summary.

If the chain of custody or cold chain is unclear, do not dispatch until the uncertainty is resolved.
