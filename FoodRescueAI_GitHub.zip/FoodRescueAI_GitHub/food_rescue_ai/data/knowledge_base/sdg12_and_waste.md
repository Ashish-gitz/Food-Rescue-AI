# SDG 12 and Food Waste

SDG 12 focuses on responsible consumption and production. Preventing surplus at the source is preferred; redistribution is a practical next step when food remains edible and safe. Measurement should report food waste reduced, meals redirected, and assumptions behind environmental conversion factors.

Impact factors in this prototype are illustrative. A production deployment should validate them with a local life-cycle assessment or a trusted program partner.
