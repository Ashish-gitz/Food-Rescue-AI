# 12-Slide Presentation Content

## Slide 1 — Food Rescue AI
- Intelligent RAG system for food-waste reduction and sustainable donation
- Primary SDG: 12 — Responsible Consumption and Production
- Secondary SDGs: 2, 11, 13

Speaker notes: Introduce the project as a decision-support prototype, not an autonomous food-safety authority.

## Slide 2 — The problem
- Edible surplus is time-sensitive
- Guidance and partner information are fragmented
- Uncertainty causes waste or unsafe handoffs

Speaker notes: Frame the problem around coordination and speed.

## Slide 3 — Who is affected
- Restaurants, hotels, campuses, and event organizers
- NGOs, food banks, and community kitchens
- Communities affected by food insecurity and landfill emissions

Speaker notes: Show the social and environmental link.

## Slide 4 — Proposed system
- One workspace for safety triage, prediction, partner matching, and reporting
- Sources and assumptions stay visible
- Human verification remains mandatory

Speaker notes: Explain the end-to-end flow.

## Slide 5 — Where AI helps
- Retrieve the right guidance from local documents
- Summarize grounded evidence
- Forecast likely surplus
- Recommend practical next actions

Speaker notes: Explain why AI adds speed and scale without pretending certainty.

## Slide 6 — RAG pipeline
- Load PDFs and guidance documents
- Split into chunks
- Create embeddings with Sentence Transformers
- Search FAISS
- Pass only retrieved context to Granite

Speaker notes: Emphasize grounded generation and the explicit “not found” behavior.

## Slide 7 — Product demo
- Enter food, quantity, preparation time, storage, and current time
- See decision, why, confidence, urgency, and sources

Speaker notes: Run the 5-minute demo script.

## Slide 8 — Partner matching
- Filter by city and accepted food category
- Rank by distance
- Show contact, hours, and capacity signal

Speaker notes: Make the next step actionable.

## Slide 9 — Environmental impact
- Meals saved
- Food waste reduced
- CO₂e avoided
- Landfill reduction

Speaker notes: State that conversion factors are illustrative and require local validation.

## Slide 10 — Responsible AI
- Fairness in partner ranking
- Transparent sources and confidence
- Privacy by minimization
- Human review for safety
- Bias and error monitoring

Speaker notes: The safe boundary is part of the product design.

## Slide 11 — Expected impact
- Faster donation decisions
- More traceable handoffs
- Reduced avoidable surplus
- A repeatable measurement framework

Speaker notes: Distinguish prototype signals from measured deployment outcomes.

## Slide 12 — Future scope
- Replace synthetic data with local partners
- Add calibrated forecasting
- Support regional language and policy sources
- Evaluate with safety leads

Speaker notes: End with validation and responsible scale.
