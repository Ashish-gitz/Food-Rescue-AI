# Food Rescue AI

Food Rescue AI is an internship-ready Streamlit prototype for reducing edible food waste. It combines a grounded Retrieval-Augmented Generation workflow with transparent surplus forecasting, city-aware partner matching, environmental impact estimates, and donation reports.

## Problem statement

How might we use AI to help food providers make faster, safer surplus-donation decisions so that edible food stays in the food system?

## Technology

- Python and Streamlit
- LangChain for document orchestration
- Sentence Transformers for embeddings
- FAISS for vector similarity search
- IBM Granite-compatible adapter with a deterministic offline fallback
- Pandas and Plotly for analysis
- ReportLab for PDF reports

## Run

```bash
cd food_rescue_ai
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

To connect an IBM Granite-compatible endpoint, configure `GRANITE_API_URL` and `GRANITE_API_KEY` in the runtime environment. Never paste credentials into source files or reports.

## RAG workflow

1. Guidance documents in `data/knowledge_base/` are loaded.
2. Documents are split into overlapping chunks.
3. Sentence Transformers and FAISS are used when available.
4. The top chunks are passed into a grounded prompt.
5. Granite is called only when configured; otherwise the local decision engine is labelled.
6. Sources and confidence are shown in the UI.

## Folder structure

```text
food_rescue_ai/
├── app.py
├── rag.py
├── vectorstore.py
├── prediction.py
├── utils.py
├── prompts.py
├── report_generator.py
├── requirements.txt
├── architecture.md
├── responsible_ai.md
├── demo_script.md
├── presentation_outline.md
└── data/
    ├── knowledge_base/
    ├── restaurants.csv
    ├── food_history.csv
    ├── ngo_database.csv
    └── food_guidelines.csv
```

## Scope and limitations

The included data and guidance are synthetic or educational placeholders for a prototype. Replace them with current official documents, local rules, validated impact factors, and consented partner data before real-world use. The assistant is not a legal, medical, or food-safety clearance system.
