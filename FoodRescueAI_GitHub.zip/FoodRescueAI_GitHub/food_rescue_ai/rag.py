"""Grounded assessment orchestration and modular model adapter."""

from __future__ import annotations

import os
from dataclasses import dataclass

try:
    import requests
except ImportError:  # Optional until a hosted Granite endpoint is configured.
    requests = None

from prompts import ASSESSMENT_PROMPT, SYSTEM_PROMPT
from utils import clamp, hours_since
from vectorstore import KnowledgeIndex, RetrievedChunk


@dataclass
class Assessment:
    decision: str
    reason: str
    action: str
    safety_note: str
    confidence: float
    urgency: str
    sources: list[RetrievedChunk]
    model: str


class GraniteAdapter:
    """Optional IBM Granite-compatible adapter.

    Set GRANITE_API_URL and GRANITE_API_KEY in the runtime to use a hosted
    endpoint. The local deterministic decision engine remains the safe fallback.
    """

    def __init__(self) -> None:
        self.endpoint = os.getenv("GRANITE_API_URL", "")
        self.api_key = os.getenv("GRANITE_API_KEY", "")

    @property
    def available(self) -> bool:
        return bool(self.endpoint and self.api_key)

    def generate(self, prompt: str) -> str | None:
        if not self.available or requests is None:
            return None
        try:
            response = requests.post(
                self.endpoint,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"prompt": f"{SYSTEM_PROMPT}\n\n{prompt}", "max_new_tokens": 360},
                timeout=20,
            )
            response.raise_for_status()
            body = response.json()
            return body.get("generated_text") or body.get("text") or body.get("answer")
        except (requests.RequestException, ValueError, TypeError):
            return None


def assess_surplus(
    index: KnowledgeIndex,
    food: str,
    quantity_kg: float,
    prepared_at: str,
    storage: str,
    current_time: str,
) -> Assessment:
    """Create a transparent safety recommendation from retrieved context."""
    elapsed = hours_since(prepared_at, current_time)
    query = f"{food} donation safety {storage} {elapsed:.1f} hours storage cold chain"
    sources = index.search(query)
    retrieval_confidence = max((chunk.score for chunk in sources), default=0.0)
    storage_is_cold = storage.lower() in {"refrigerated", "cold chain"}

    if not storage_is_cold:
        decision = "Hold for review"
        reason = "Storage is not confirmed as refrigerated, so the cold-chain requirement cannot be verified."
        action = "Do not dispatch. Ask the food-safety lead to verify time, temperature, and packaging."
        urgency = "Immediate review"
    elif elapsed <= 4:
        decision = "Likely suitable"
        reason = f"The case is within a short post-preparation window ({elapsed:.1f} hours) and refrigerated storage is reported."
        action = "Label the batch, record the handoff time, and confirm the receiving partner can accept it now."
        urgency = "Dispatch within 1 hour"
    elif elapsed <= 8:
        decision = "Review before donation"
        reason = f"The elapsed time is {elapsed:.1f} hours; a trained food-safety lead should verify the documented cold chain."
        action = "Prioritize a nearby partner and dispatch only after the safety lead signs off."
        urgency = "Dispatch today"
    else:
        decision = "Do not donate yet"
        reason = f"The reported elapsed time is {elapsed:.1f} hours, and the available case data is not enough to clear the food."
        action = "Segregate the batch and follow the organization's disposal or reprocessing SOP."
        urgency = "Escalate now"

    confidence = clamp(0.58 + retrieval_confidence * 0.32 + (0.08 if storage_is_cold else 0), 0.45, 0.96)
    prompt = ASSESSMENT_PROMPT.format(
        food=food,
        quantity_kg=quantity_kg,
        prepared_at=prepared_at,
        storage=storage,
        current_time=current_time,
        context="\n\n".join(chunk.text for chunk in sources),
    )
    model_text = GraniteAdapter().generate(prompt)
    if model_text:
        reason = model_text
        model = "IBM Granite adapter"
    else:
        model = "Transparent local decision engine"

    return Assessment(decision, reason, action, "This is decision support, not a legal or medical clearance. Verify local rules and the cold chain.", round(confidence, 2), urgency, sources, model)
