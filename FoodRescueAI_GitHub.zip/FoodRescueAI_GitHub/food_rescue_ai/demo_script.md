# Five-Minute Demo Script

## 0:00–0:45 — The problem

“Every day, kitchens have edible surplus but the decision window is short. Staff need to know what the food is, how it was stored, who can receive it, and what impact a rescue would create. Today that information is often spread across SOPs, calls, and spreadsheets.”

## 0:45–1:30 — The solution

“Food Rescue AI brings those steps into one workspace. It is designed around SDG 12, with links to SDG 2, SDG 11, and SDG 13. The assistant does not replace a food-safety lead. It retrieves the relevant guidance, makes the reasoning visible, and turns a handoff into a traceable report.”

## 1:30–2:30 — Grounded assessment

Open Donation Assistant. Enter “Cooked rice and dal,” 24 kg, a preparation time three hours earlier, and refrigerated storage. Run the assessment. Point out the recommendation, confidence, urgency, model path, and the retrieved source snippets. Explain that the app labels a local fallback when Granite is not configured.

## 2:30–3:15 — Forecast and partner

Open Surplus Forecast. Explain that the sample uses a transparent weekday baseline and is intentionally not presented as a production forecasting model. Open Partners, filter by city and food type, then show distance, accepted food, operating hours, and contact action.

## 3:15–4:00 — Impact and report

Open Environmental Impact. Move the rescued-food slider and show meals saved, waste reduced, CO₂e avoided, and landfill reduction. Explain that the factors are illustrative until validated locally. Open Reports and download the CSV and PDF summary.

## 4:00–5:00 — Responsible AI and next steps

Open Methodology. Walk through the RAG pipeline: embed, retrieve with FAISS, ground the prompt, generate with Granite or a labelled fallback, and verify with a human. Close with the next step: replace synthetic documents and factors with current local guidance, collect feedback from kitchens and NGOs, and evaluate both false clearance and false rejection.
