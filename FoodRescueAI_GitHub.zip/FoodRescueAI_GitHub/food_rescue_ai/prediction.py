"""Surplus forecasting utilities."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_food_history(path: Path | None = None) -> pd.DataFrame:
    """Load the sample history dataset."""
    source = path or Path(__file__).resolve().parent / "data" / "food_history.csv"
    frame = pd.read_csv(source, parse_dates=["date"])
    return frame.sort_values("date")


def forecast_next_days(history: pd.DataFrame, days: int = 7) -> pd.DataFrame:
    """Use a transparent weekday baseline for a demo forecast."""
    history = history.copy()
    history["weekday"] = history["date"].dt.dayofweek
    baseline = history.groupby("weekday")["surplus_kg"].mean()
    last_date = history["date"].max()
    rows: list[dict[str, object]] = []
    for offset in range(1, days + 1):
        date = last_date + pd.Timedelta(days=offset)
        expected = float(baseline.get(date.dayofweek, history["surplus_kg"].mean()))
        rows.append(
            {
                "date": date,
                "expected_kg": round(expected, 1),
                "recommendation": "Pre-book a partner" if expected >= 30 else "Monitor portions",
            }
        )
    return pd.DataFrame(rows)
