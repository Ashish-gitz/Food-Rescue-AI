"""Knowledge-base indexing with FAISS and a deterministic offline fallback."""

from __future__ import annotations

import re
from dataclasses import dataclass

from utils import compact_text, read_text_files


@dataclass
class RetrievedChunk:
    source: str
    text: str
    score: float


class KnowledgeIndex:
    """Build and query a small local index.

    Sentence Transformers + FAISS are used when available. A keyword scorer is
    intentionally retained so the demo is runnable before model downloads or
    IBM credentials are configured.
    """

    def __init__(self, chunk_size: int = 850, overlap: int = 120) -> None:
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.chunks: list[RetrievedChunk] = []
        self._faiss_index = None
        self._embedder = None

    def build(self) -> "KnowledgeIndex":
        raw_documents = read_text_files()
        self.chunks = []
        for document in raw_documents:
            text = document["text"]
            start = 0
            while start < len(text):
                chunk = text[start : start + self.chunk_size].strip()
                if chunk:
                    self.chunks.append(RetrievedChunk(document["source"], chunk, 0.0))
                start += self.chunk_size - self.overlap

        try:
            from langchain_community.vectorstores import FAISS
            from langchain_core.documents import Document
            from langchain_huggingface import HuggingFaceEmbeddings

            self._embedder = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
            documents = [Document(page_content=chunk.text, metadata={"source": chunk.source}) for chunk in self.chunks]
            self._faiss_index = FAISS.from_documents(documents, self._embedder)
        except Exception:
            self._faiss_index = None
        return self

    def search(self, query: str, k: int = 4) -> list[RetrievedChunk]:
        """Return the top grounded chunks with a normalized confidence score."""
        if self._faiss_index is not None:
            try:
                matches = self._faiss_index.similarity_search_with_score(query, k=k)
                results: list[RetrievedChunk] = []
                for document, distance in matches:
                    results.append(
                        RetrievedChunk(
                            source=document.metadata.get("source", "Knowledge base"),
                            text=document.page_content,
                            score=round(1 / (1 + float(distance)), 3),
                        )
                    )
                return results
            except Exception:
                pass

        tokens = set(re.findall(r"[a-z0-9]+", query.lower()))
        scored: list[RetrievedChunk] = []
        for chunk in self.chunks:
            chunk_tokens = set(re.findall(r"[a-z0-9]+", chunk.text.lower()))
            overlap = len(tokens & chunk_tokens)
            score = overlap / max(1, len(tokens))
            scored.append(RetrievedChunk(chunk.source, chunk.text, round(score, 3)))
        return sorted(scored, key=lambda item: item.score, reverse=True)[:k]

    @property
    def mode(self) -> str:
        return "FAISS + Sentence Transformers" if self._faiss_index is not None else "Keyword fallback (offline)"

    def source_preview(self, chunks: list[RetrievedChunk]) -> list[dict[str, str | float]]:
        """Format sources for the UI."""
        return [
            {"source": chunk.source, "preview": compact_text(chunk.text), "score": chunk.score}
            for chunk in chunks
        ]
