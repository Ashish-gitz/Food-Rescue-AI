"""Food Rescue AI Streamlit application."""

from __future__ import annotations

from datetime import datetime, timedelta

import pandas as pd
import plotly.express as px
import streamlit as st

from prediction import forecast_next_days, load_food_history
from rag import assess_surplus
from report_generator import build_csv, build_pdf
from utils import KNOWLEDGE_DIR, format_kg
from vectorstore import KnowledgeIndex


st.set_page_config(page_title="Food Rescue AI", page_icon="♻", layout="wide", initial_sidebar_state="expanded")

st.markdown(
    """
    <style>
    .block-container { max-width: 1400px; padding-top: 2rem; }
    .impact-card { border: 1px solid #d9e4df; border-radius: 16px; padding: 18px; background: #f7fbf9; }
    .eyebrow { letter-spacing: .12em; text-transform: uppercase; color: #6a7c75; font-size: .72rem; font-weight: 700; }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def get_index() -> KnowledgeIndex:
    return KnowledgeIndex().build()


def render_sidebar() -> str:
    st.sidebar.title("Food Rescue AI")
    st.sidebar.caption("From surplus to shared meals")
    page = st.sidebar.radio(
        "Navigate",
        ["Command center", "Donation assistant", "Surplus forecast", "Partners", "Environmental impact", "Reports", "Methodology"],
    )
    st.sidebar.divider()
    st.sidebar.caption("Primary SDG")
    st.sidebar.markdown("**SDG 12** · Responsible Consumption")
    st.sidebar.caption("Also supports SDG 2, 11, and 13")
    st.sidebar.info("AI mode: " + get_index().mode)
    return page


def command_center() -> None:
    st.markdown('<div class="eyebrow">Food Rescue AI · sustainability operations</div>', unsafe_allow_html=True)
    st.title("Keep good food in the food system.")
    st.write("A grounded decision-support workspace for kitchens, campuses, hotels, and community food partners.")
    columns = st.columns(4)
    for column, value, label in zip(columns, ["1,248", "364 kg", "82%", "4.6 t"], ["Meals redirected", "Waste avoided", "Partner match rate", "CO₂e avoided"]):
        with column:
            st.markdown(f'<div class="impact-card"><div class="eyebrow">{label}</div><h2>{value}</h2></div>', unsafe_allow_html=True)

    st.subheader("Today’s rescue queue")
    queue = pd.DataFrame(
        [
            ["Campus cafeteria", "Cooked rice & dal", "42 kg", "Review before donation", "Dispatch today"],
            ["Green Leaf Hotel", "Prepared vegetables", "18 kg", "Likely suitable", "Dispatch within 1 hour"],
            ["Northside Events", "Sandwiches", "27 kg", "Hold for review", "Immediate review"],
        ],
        columns=["Source", "Surplus", "Quantity", "AI signal", "Urgency"],
    )
    st.dataframe(queue, use_container_width=True, hide_index=True)
    st.info("Start with the Donation Assistant to assess a new surplus batch. The AI recommendation is not a substitute for a trained food-safety lead.")


def donation_assistant() -> None:
    st.markdown('<div class="eyebrow">Grounded assessment</div>', unsafe_allow_html=True)
    st.title("Can this food be donated?")
    st.write("Describe the batch and retrieve relevant guidance before deciding what to do next.")
    with st.form("assessment"):
        left, right = st.columns(2)
        with left:
            food = st.text_input("Food name", "Cooked rice and dal")
            quantity = st.number_input("Quantity (kg)", min_value=0.1, value=24.0, step=0.5)
            prepared = st.text_input(
                "Preparation time (ISO)",
                (datetime.now() - timedelta(hours=3)).replace(microsecond=0).isoformat(timespec="minutes"),
            )
        with right:
            storage = st.selectbox("Storage method", ["Refrigerated", "Cold chain", "Room temperature", "Unknown"])
            current = st.text_input("Current time (ISO)", datetime.now().replace(microsecond=0).isoformat(timespec="minutes"))
            submitted = st.form_submit_button("Run grounded assessment", type="primary")

    if submitted:
        try:
            result = assess_surplus(get_index(), food, quantity, prepared, storage, current)
            st.session_state["last_assessment"] = result
        except ValueError:
            st.error("Use ISO date-time values such as 2026-09-10T14:30 for preparation and current time.")

    result = st.session_state.get("last_assessment")
    if not result:
        st.success("Ready. The assessment will show the decision, reasoning, sources, confidence, and urgency.")
        return
    st.divider()
    result_col, signal_col = st.columns([1.35, 1])
    with result_col:
        st.markdown(f"### {result.decision}")
        st.write(result.reason)
        st.markdown(f"**Recommended next step**  \n{result.action}")
        st.caption(result.safety_note)
    with signal_col:
        st.metric("Confidence", f"{result.confidence:.0%}")
        st.progress(result.confidence)
        st.metric("Donation urgency", result.urgency)
        st.caption(f"Model path: {result.model}")
    st.subheader("Retrieved guidance")
    for source in result.sources:
        with st.expander(f"{source.source} · retrieval score {source.score:.2f}"):
            st.write(source.text)


def surplus_forecast() -> None:
    st.markdown('<div class="eyebrow">Predict & prevent</div>', unsafe_allow_html=True)
    st.title("Surplus forecast")
    history = load_food_history()
    forecast = forecast_next_days(history)
    chart_data = history.rename(columns={"surplus_kg": "kg"}).assign(series="Observed")[["date", "kg", "series"]]
    forecast_data = forecast.rename(columns={"expected_kg": "kg"}).assign(series="Expected")[["date", "kg", "series"]]
    chart = px.line(pd.concat([chart_data, forecast_data]), x="date", y="kg", color="series", markers=True, color_discrete_map={"Observed": "#2b7564", "Expected": "#f2a65a"})
    chart.update_layout(height=360, margin=dict(l=0, r=0, t=20, b=0), legend_title_text="")
    st.plotly_chart(chart, use_container_width=True)
    st.dataframe(forecast, use_container_width=True, hide_index=True, column_config={"expected_kg": st.column_config.NumberColumn("Expected surplus", format="%.1f kg")})
    st.caption("This prototype uses a transparent weekday baseline. Replace it with a validated forecasting model after collecting representative local data.")


def partners() -> None:
    st.markdown('<div class="eyebrow">Community matching</div>', unsafe_allow_html=True)
    st.title("Find a food rescue partner")
    partners_frame = pd.read_csv("data/ngo_database.csv")
    city = st.selectbox("Pickup city", sorted(partners_frame["city"].unique()))
    accepted_food = st.selectbox("Food type", sorted(partners_frame["accepts"].unique()))
    filtered = partners_frame[(partners_frame["city"] == city) & (partners_frame["accepts"] == accepted_food)].sort_values("distance_km")
    st.write(f"{len(filtered)} partner(s) match the current filters.")
    for _, row in filtered.iterrows():
        with st.container(border=True):
            left, right = st.columns([2, 1])
            with left:
                st.subheader(row["name"])
                st.write(row["description"])
                st.caption(f"Accepts: {row['accepts']} · Hours: {row['hours']}")
            with right:
                st.metric("Distance", f"{row['distance_km']:.1f} km")
                st.button("Copy contact", key=f"contact-{row['name']}")


def environmental_impact() -> None:
    st.markdown('<div class="eyebrow">Make the impact legible</div>', unsafe_allow_html=True)
    st.title("Environmental impact")
    rescued = st.slider("Food rescued (kg)", 5, 500, 120, 5)
    meals = round(rescued / 0.45)
    co2 = round(rescued * 2.5, 1)
    landfill = round(rescued * 0.72, 1)
    columns = st.columns(4)
    for column, value, label in zip(columns, [meals, format_kg(rescued), f"{co2} kg", f"{landfill} kg"], ["Meals saved", "Food waste reduced", "CO₂e avoided", "Landfill reduction"]):
        with column:
            st.metric(label, value)
    chart = px.bar(pd.DataFrame({"impact": ["Meals saved (×10)", "CO₂e avoided", "Landfill reduction"], "value": [meals / 10, co2, landfill]}), x="impact", y="value", color="impact", color_discrete_sequence=["#2b7564", "#f2a65a", "#9abd8c"])
    chart.update_layout(showlegend=False, height=320, margin=dict(l=0, r=0, t=20, b=0))
    st.plotly_chart(chart, use_container_width=True)
    st.caption("Illustrative conversion factors for this prototype. Validate factors with a local LCA or program partner before public reporting.")


def reports() -> None:
    st.markdown('<div class="eyebrow">Close the loop</div>', unsafe_allow_html=True)
    st.title("Donation report generator")
    summary = {"food_batch": "Cooked rice and dal", "quantity_kg": 24, "partner": "City Harvest Collective", "status": "Review before donation", "meals_saved": 53, "co2e_avoided_kg": 60, "generated_by": "Food Rescue AI"}
    st.dataframe(pd.DataFrame([summary]).T.rename(columns={0: "Value"}), use_container_width=True)
    st.download_button("Download CSV summary", build_csv(summary), "food-rescue-summary.csv", "text/csv")
    st.download_button("Download PDF report", build_pdf(summary), "food-rescue-summary.pdf", "application/pdf")
    st.success("Reports are designed for traceability: they preserve the case details, recommendation, impact estimate, and safety caveat.")


def methodology() -> None:
    st.markdown('<div class="eyebrow">Project submission</div>', unsafe_allow_html=True)
    st.title("How Food Rescue AI works")
    st.markdown(
        """
        **Problem statement**  
        How might we use AI to help food providers make faster, safer surplus-donation decisions so that edible food stays in the food system?

        **AI role**  
        Retrieval-Augmented Generation (RAG) grounds answers in food-safety and donation guidance. A transparent weekday baseline forecasts surplus, while a simple matching layer ranks nearby partners.

        **Responsible AI**  
        The system shows its sources, confidence, assumptions, and uncertainty. It does not make legal or medical claims, infer sensitive personal attributes, or replace a trained food-safety lead.
        """
    )
    st.subheader("RAG workflow")
    st.code("User case → Sentence Transformer embeddings → FAISS similarity search → grounded prompt → Granite adapter / local fallback → cited recommendation", language="text")
    st.subheader("12-slide presentation outline")
    slides = [
        ("1. Food Rescue AI", "Turning surplus into shared meals", "Introduce the project and primary SDG 12 alignment."),
        ("2. The problem", "Edible surplus is time-sensitive and fragmented", "Connect the problem to kitchens, communities, and climate."),
        ("3. Who is affected", "Providers, food banks, families, and cities", "Name the users and the coordination gap."),
        ("4. Proposed solution", "One workspace for safety, matching, and impact", "Walk through the value proposition."),
        ("5. Where AI helps", "Retrieve, predict, recommend, explain", "Show why AI is useful without overstating automation."),
        ("6. RAG pipeline", "Search the right guidance before generating", "Explain embeddings, FAISS, and grounded prompting."),
        ("7. Product demo", "Assess a surplus batch", "Use the demo flow from the assistant screen."),
        ("8. Partner matching", "Make the next handoff actionable", "Show city and accepted-food filters."),
        ("9. Environmental impact", "Turn kilos into understandable outcomes", "Explain illustrative conversion factors."),
        ("10. Responsible AI", "Transparent, privacy-aware, human-supervised", "Cover fairness, transparency, privacy, ethics, and bias."),
        ("11. Expected impact", "Less waste, more meals, better coordination", "Share prototype metrics and measurement plan."),
        ("12. Next steps", "Validate locally, then scale carefully", "Close with data collection, evaluation, and future scope."),
    ]
    for title, subtitle, notes in slides:
        with st.expander(f"{title} · {subtitle}"):
            st.write(f"Speaker notes: {notes}")
    st.subheader("Knowledge base")
    st.write(f"{len(list(KNOWLEDGE_DIR.glob('*')))} local guidance documents are ready for indexing from `{KNOWLEDGE_DIR}`.")


page = render_sidebar()
if page == "Command center":
    command_center()
elif page == "Donation assistant":
    donation_assistant()
elif page == "Surplus forecast":
    surplus_forecast()
elif page == "Partners":
    partners()
elif page == "Environmental impact":
    environmental_impact()
elif page == "Reports":
    reports()
else:
    methodology()