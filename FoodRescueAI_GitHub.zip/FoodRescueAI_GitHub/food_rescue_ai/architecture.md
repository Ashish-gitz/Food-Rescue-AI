# Food Rescue AI — Architecture

## Mermaid flowchart

```mermaid
flowchart LR
  A[Kitchen surplus details] --> B[Normalize case]
  B --> C[Sentence Transformer embeddings]
  C --> D[FAISS similarity search]
  D --> E[Top guidance chunks]
  E --> F[Grounded prompt]
  F --> G{Granite configured?}
  G -->|Yes| H[IBM Granite adapter]
  G -->|No| I[Transparent local decision engine]
  H --> J[Recommendation + sources + confidence]
  I --> J
  J --> K[Human safety lead verifies]
  K --> L[Partner handoff + impact report]
```

## Text architecture

```text
Streamlit UI
    |
    +-- Donation Assistant ----> rag.py
    |                              |
    |                              +-- vectorstore.py
    |                              |      +-- PDF/Markdown loader
    |                              |      +-- Sentence Transformers
    |                              |      +-- FAISS / keyword fallback
    |                              |
    |                              +-- GraniteAdapter (optional)
    |
    +-- Surplus Forecast --------> prediction.py + food_history.csv
    +-- Partner Matching --------> ngo_database.csv
    +-- Environmental Impact ----> transparent conversion factors
    +-- Report Generator --------> CSV + reportlab PDF
```

## Design decisions

- Grounding happens before generation, with source snippets exposed to the user.
- The prototype does not fail closed into a fake AI answer when the model is unavailable; it uses a transparent local fallback and labels it.
- A human food-safety lead remains in the loop for final clearance.
- Sample data is synthetic and should not be represented as live NGO capacity.
