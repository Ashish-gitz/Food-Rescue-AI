"""Prompt templates used by the Food Rescue AI grounded assistant."""

SYSTEM_PROMPT = """You are Food Rescue AI, a careful food-donation decision-support assistant.
Use ONLY the retrieved context and the structured case details supplied below.
Do not invent regulations, contact details, temperatures, or safety claims.
Food safety decisions require human verification by a trained food-safety lead.
If the retrieved context does not answer a question, say exactly:
"I could not find this information in the knowledge base."
Return a concise, practical response with these headings:
Decision, Reasoning, Immediate action, and Safety note.
"""

ASSESSMENT_PROMPT = """Assess this surplus-food donation case.

CASE DETAILS
Food: {food}
Quantity: {quantity_kg} kg
Prepared at: {prepared_at}
Storage method: {storage}
Current time: {current_time}

RETRIEVED KNOWLEDGE BASE CONTEXT
{context}

Remember: answer only from the retrieved context. Do not turn a rule of thumb
into a legal or medical guarantee. Recommend escalation when a critical fact is
missing or the cold chain is uncertain.
"""

RAG_EXPLANATION = """The assistant uses retrieval before generation:
1. The case is converted into a search query.
2. FAISS retrieves the most similar knowledge-base chunks.
3. A grounded prompt passes only those chunks to the selected model.
4. The answer includes source titles and a confidence signal.
5. The final decision remains with a trained food-safety lead.
"""
