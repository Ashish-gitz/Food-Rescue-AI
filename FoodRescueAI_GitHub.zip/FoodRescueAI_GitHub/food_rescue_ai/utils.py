"""Shared utilities for Food Rescue AI."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable


PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
KNOWLEDGE_DIR = DATA_DIR / "knowledge_base"


def parse_datetime(value: str) -> datetime:
    """Parse the ISO-like values produced by the Streamlit inputs."""
    return datetime.fromisoformat(value)


def hours_since(prepared_at: str, current_time: str) -> float:
    """Return elapsed hours, never silently returning a negative duration."""
    elapsed = (parse_datetime(current_time) - parse_datetime(prepared_at)).total_seconds() / 3600
    return max(0.0, elapsed)


def clamp(value: float, lower: float, upper: float) -> float:
    """Clamp a number into an inclusive range."""
    return max(lower, min(upper, value))


def format_kg(value: float) -> str:
    """Format kilogram values consistently across UI and reports."""
    return f"{value:,.1f} kg"


def read_text_files(directory: Path = KNOWLEDGE_DIR) -> list[dict[str, str]]:
    """Load Markdown, TXT, and PDF files from the knowledge-base directory."""
    documents: list[dict[str, str]] = []
    if not directory.exists():
        return documents

    for path in sorted(directory.iterdir()):
        if path.suffix.lower() in {".md", ".txt"}:
            documents.append({"source": path.name, "text": path.read_text(encoding="utf-8")})
        elif path.suffix.lower() == ".pdf":
            try:
                from pypdf import PdfReader

                text = "\n".join(page.extract_text() or "" for page in PdfReader(str(path)).pages)
                if text.strip():
                    documents.append({"source": path.name, "text": text})
            except Exception:
                # A missing optional PDF parser should not take down the offline demo.
                continue
    return documents


def compact_text(value: str, limit: int = 360) -> str:
    """Collapse whitespace and truncate source previews."""
    normalized = " ".join(value.split())
    return normalized if len(normalized) <= limit else f"{normalized[:limit].rstrip()}…"


def csv_download_bytes(rows: Iterable[dict]) -> bytes:
    """Create CSV bytes without requiring pandas in the report path."""
    import csv
    import io

    rows = list(rows)
    if not rows:
        return b""
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8")
