"""Donation report exports."""

from __future__ import annotations

from datetime import datetime
from io import BytesIO


def build_csv(summary: dict[str, object]) -> bytes:
    import csv
    import io

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["Food Rescue AI donation summary"])
    for key, value in summary.items():
        writer.writerow([key.replace("_", " ").title(), value])
    return buffer.getvalue().encode("utf-8")


def build_pdf(summary: dict[str, object]) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    from reportlab.lib import colors

    output = BytesIO()
    document = SimpleDocTemplate(output, pagesize=A4, rightMargin=42, leftMargin=42, topMargin=42, bottomMargin=42)
    styles = getSampleStyleSheet()
    story = [
        Paragraph("Food Rescue AI", styles["Title"]),
        Paragraph("Donation impact summary", styles["Heading2"]),
        Paragraph(f"Generated {datetime.now().strftime('%d %b %Y, %H:%M')}", styles["Normal"]),
        Spacer(1, 18),
    ]
    table = Table([["Metric", "Value"]] + [[key.replace("_", " ").title(), str(value)] for key, value in summary.items()], colWidths=[250, 200])
    table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#163b35")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d0d8d4")), ("PADDING", (0, 0), (-1, -1), 8)]))
    story.append(table)
    story.append(Spacer(1, 18))
    story.append(Paragraph("Safety note: this report is decision support. Verify local food-safety rules and receiving-partner requirements before dispatch.", styles["BodyText"]))
    document.build(story)
    return output.getvalue()
