# Responsible AI Considerations

## Fairness

Partner ranking uses distance, city, accepted food type, and operating hours rather than assumptions about neighborhoods, income, language, or recipient identity. Future data collection should test whether smaller organizations are systematically hidden by capacity or distance filters.

## Transparency and explainability

Every assessment exposes the retrieved source documents, retrieval score, confidence signal, model path, assumptions, and recommended human action. The system distinguishes “likely suitable” from a legal clearance.

## Privacy

The prototype uses organization-level synthetic data and does not request diner, recipient, health, or identity information. Reports should exclude personal data unless a documented operational need and retention policy exist.

## Ethics and safety

Food safety is a high-consequence domain. The assistant is a triage and documentation tool, not an autonomous dispatch authority. Unknown storage history, missing temperature evidence, and conflicting local rules trigger human review.

## Bias mitigation

Evaluation should include different food categories, cities, storage scenarios, language styles, and organization sizes. Monitor false-clearance and false-rejection rates separately. Keep a route for the safety lead to override and annotate recommendations.

## Environmental claims

CO₂e and landfill estimates use illustrative factors in this prototype. Public reporting should use validated local factors, show the equation, and retain uncertainty ranges.
