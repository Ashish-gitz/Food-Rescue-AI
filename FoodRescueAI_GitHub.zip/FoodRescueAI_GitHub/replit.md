# Food Rescue AI

Food Rescue AI is a sustainability decision-support prototype that helps kitchens assess surplus food, find donation partners, and measure avoided waste.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/food-rescue-ai/` — runnable React dashboard and internship demo surface.
- `food_rescue_ai/` — Python/Streamlit reference implementation, RAG modules, datasets, reports, architecture, and submission content.
- `food_rescue_ai/data/knowledge_base/` — local guidance documents indexed by the RAG pipeline.

## Architecture decisions

- The browser demo is deterministic and works offline so the core flow is always present during an internship presentation.
- The Python implementation uses FAISS and Sentence Transformers when available, with a labelled keyword fallback when model downloads are unavailable.
- IBM Granite is an optional adapter configured through environment secrets; the app does not hard-code credentials or pretend a fallback is Granite.
- Safety recommendations expose sources, confidence, uncertainty, and human-review steps instead of making autonomous clearance claims.

## Product

The product includes a command center, grounded donation assistant, surplus forecast, NGO partner directory, environmental impact calculator, report exports, RAG methodology, responsible-AI checklist, and a 12-slide presentation outline.

## User preferences

The requested deliverable is end-to-end and internship-ready, including runnable code plus documentation and demo materials.

## Gotchas

- Replace the synthetic datasets and educational knowledge-base notes with current local guidance and validated partner data before real-world deployment.
- Environmental conversion factors in the prototype are illustrative and must be validated before public claims.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
