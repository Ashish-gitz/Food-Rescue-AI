import { useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  ArrowDownRight,
  ArrowUpRight,
  Bell,
  BookOpen,
  BrainCircuit,
  Calculator,
  CalendarDays,
  ChartNoAxesCombined,
  Check,
  ChevronDown,
  ChevronRight,
  CircleCheck,
  Clock3,
  Database,
  Download,
  ExternalLink,
  FileSpreadsheet,
  FileText,
  Handshake,
  Info,
  LayoutDashboard,
  Leaf,
  Mail,
  MapPin,
  Menu,
  Phone,
  Presentation,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  TriangleAlert,
  TrendingUp,
  X,
} from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type SurplusAssessment = {
  food: string;
  quantityKg: number;
  preparedAt: string;
  storage: string;
  currentTime: string;
  decision: 'Donate' | 'Review' | 'Do not donate';
  reason: string;
  confidence: number;
  urgency: string;
  sources: string[];
};

type ForecastRow = { date: string; expectedKg: number; actualKg: number; preventedKg: number };
type Partner = { name: string; city: string; distanceKm: number; contact: string; accepts: string[]; hours: string; status: string };
type Impact = { mealsSaved: number; wasteReducedKg: number; co2SavedKg: number; landfillReducedKg: number };
type Resource = { title: string; type: string; description: string; href: string };

const navItems = [
  { href: '/', label: 'Command center', icon: LayoutDashboard },
  { href: '/assistant', label: 'Safety assistant', icon: ShieldCheck },
  { href: '/forecast', label: 'Surplus forecast', icon: ChartNoAxesCombined },
  { href: '/partners', label: 'Community partners', icon: Handshake },
  { href: '/impact', label: 'Impact ledger', icon: Leaf },
  { href: '/reports', label: 'Reports', icon: FileText },
  { href: '/methodology', label: 'Methodology', icon: BookOpen },
];

const assessmentSeed: SurplusAssessment = {
  food: 'Vegetable tagine with couscous',
  quantityKg: 18.5,
  preparedAt: '2025-02-21T10:30',
  storage: 'Refrigerated at 3°C',
  currentTime: '2025-02-21T15:10',
  decision: 'Donate',
  reason: 'The food has been cooled and held below 5°C. At 4h 40m since preparation, it is inside the recommended cold-hold window for donation.',
  confidence: 92,
  urgency: 'Collect within 2 hours',
  sources: ['USDA. Food Safety and Inspection Service — Refrigeration and Food Safety, 2024.', 'FDA Food Code 2022 · §3-501.17 Time as a Public Health Control.', 'City Harvest donor guide · Cooling, storage and transport checklist.'],
};

const forecastSeed: ForecastRow[] = [
  { date: 'Mon 17', expectedKg: 42, actualKg: 39, preventedKg: 31 },
  { date: 'Tue 18', expectedKg: 48, actualKg: 52, preventedKg: 38 },
  { date: 'Wed 19', expectedKg: 44, actualKg: 41, preventedKg: 35 },
  { date: 'Thu 20', expectedKg: 57, actualKg: 61, preventedKg: 42 },
  { date: 'Fri 21', expectedKg: 64, actualKg: 67, preventedKg: 48 },
  { date: 'Sat 22', expectedKg: 71, actualKg: 74, preventedKg: 52 },
  { date: 'Sun 23', expectedKg: 53, actualKg: 51, preventedKg: 40 },
];

const partnersSeed: Partner[] = [
  { name: 'Northside Community Pantry', city: 'Oakland', distanceKm: 2.4, contact: '(510) 555-0182', accepts: ['Prepared meals', 'Produce', 'Bakery'], hours: 'Open until 18:30', status: 'Accepting today' },
  { name: 'East Bay Food Collective', city: 'Oakland', distanceKm: 4.8, contact: 'dispatch@ebfoodcollective.org', accepts: ['Prepared meals', 'Dairy', 'Produce'], hours: 'Pickup window 16:00–19:00', status: 'Pickup in 42 min' },
  { name: 'Harbor Light Mutual Aid', city: 'Berkeley', distanceKm: 6.1, contact: '(510) 555-0127', accepts: ['Prepared meals', 'Bakery'], hours: 'Open until 17:00', status: 'Limited capacity' },
  { name: 'Fruitvale Family Resource Hub', city: 'Oakland', distanceKm: 7.6, contact: 'hello@fruitvalehub.org', accepts: ['Produce', 'Shelf-stable'], hours: 'Open until 20:00', status: 'Accepting today' },
];

const resources: Resource[] = [
  { title: 'Food donation safety playbook', type: 'PDF', description: 'A practical checklist for cooling, labeling, holding and handoff.', href: '#safety-playbook' },
  { title: 'RAG evaluation notebook', type: 'NOTEBOOK', description: 'How retrieved evidence is scored before a recommendation is shown.', href: '#rag-notebook' },
  { title: 'Internship project brief', type: 'DOC', description: 'Problem framing, user research prompts and implementation notes.', href: '#project-brief' },
  { title: '12-slide presentation outline', type: 'SLIDES', description: 'A ready-to-present story from surplus signal to community value.', href: '#slides' },
];

function IconBadge({ icon: Icon, tone = 'sun' }: { icon: typeof Leaf; tone?: 'sun' | 'mint' | 'navy' | 'coral' }) {
  return <span className={`icon-badge badge-${tone}`}><Icon size={17} strokeWidth={1.8} /></span>;
}

function MetricCard({ label, value, suffix, detail, trend, icon: Icon, tone }: { label: string; value: string; suffix?: string; detail: string; trend?: 'up' | 'down'; icon: typeof Leaf; tone: 'sun' | 'mint' | 'navy' | 'coral' }) {
  return (
    <article className="metric-card" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div className="metric-top"><IconBadge icon={Icon} tone={tone} /><span className="metric-label">{label}</span></div>
      <div className="metric-value">{value}<small>{suffix}</small></div>
      <div className={`metric-detail ${trend === 'down' ? 'trend-down' : ''}`}>{trend === 'up' && <ArrowUpRight size={14} />}{trend === 'down' && <ArrowDownRight size={14} />}{detail}</div>
    </article>
  );
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <header className="page-header page-enter"><div><div className="eyebrow">{eyebrow}</div><h1 className="display page-title">{title}</h1><p className="page-description">{description}</p></div>{action && <div className="header-action">{action}</div>}</header>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="app-shell noise">
      <aside className={`side-rail ${mobileOpen ? 'mobile-open' : ''}`}>
        <div className="rail-brand">
          <div className="brand-mark"><Leaf size={18} /></div>
          <div className="rail-brand-copy"><strong>food rescue</strong><span>AI operations</span></div>
          <button className="rail-close" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-close-navigation"><X size={18} /></button>
        </div>
        <div className="rail-title">Workspace</div>
        <nav>
          {navItems.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href} className={`rail-link ${location === href ? 'active' : ''}`} onClick={() => setMobileOpen(false)} data-testid={`link-${label.toLowerCase().replaceAll(' ', '-')}`}>
              <Icon size={18} /><span className="rail-label">{label}</span>{location === href && <span className="active-dot" />}
            </Link>
          ))}
        </nav>
        <div className="rail-footer">
          <div className="rail-status"><span className="status-pulse" /><div><strong>Local mode</strong><span>No API connected</span></div></div>
          <div className="rail-user"><span className="avatar">MK</span><div><strong>Maya Kim</strong><span>Kitchen lead</span></div><ChevronDown size={15} /></div>
        </div>
      </aside>
      <main className="main-content">
        <div className="mobile-topbar"><button onClick={() => setMobileOpen(true)} aria-label="Open navigation" data-testid="button-open-navigation"><Menu size={21} /></button><span className="mono">FR / {location === '/' ? 'overview' : location.slice(1)}</span><Bell size={19} /></div>
        <div className="content-wrap">{children}</div>
      </main>
    </div>
  );
}

function Home() {
  const [acknowledged, setAcknowledged] = useState<string[]>([]);
  const active = [
    { id: 'tagine', name: 'Vegetable tagine', source: 'Tonight’s prep · 18.5 kg', age: '4h 40m', status: 'Donate', tone: 'good' },
    { id: 'bread', name: 'Sourdough loaves', source: 'Bakery close · 9.2 kg', age: '1h 10m', status: 'Donate', tone: 'good' },
    { id: 'salmon', name: 'Citrus salmon portions', source: 'Service surplus · 6.8 kg', age: '6h 05m', status: 'Review', tone: 'warn' },
  ];
  return <div className="page-enter">
    <div className="topline"><span className="mono">FR / OVERVIEW</span><span className="date-chip"><CalendarDays size={14} /> Friday, 21 February 2025</span></div>
    <section className="hero-panel">
      <div className="hero-copy"><div className="eyebrow warm">Good food, still in the story</div><h1 className="display hero-title">Turn today’s surplus<br /><em>into someone’s supper.</em></h1><p>One calm place to check safety, find a neighbor, and make the impact visible.</p><Link href="/assistant" className="primary-button" data-testid="link-start-assessment">Assess a surplus <ChevronRight size={16} /></Link></div>
      <div className="hero-orbit"><div className="orbit-ring ring-one" /><div className="orbit-ring ring-two" /><div className="orbit-core"><span>today</span><strong>47.2</strong><small>kg redirected</small></div><div className="orbit-note note-top">+ 13 households</div><div className="orbit-note note-bottom">3 active handoffs</div></div>
    </section>
    <div className="section-heading"><div><div className="eyebrow">Live ledger</div><h2 className="section-title">This week, so far</h2></div><Link href="/reports" className="text-link" data-testid="link-view-report">View full report <ArrowUpRight size={15} /></Link></div>
    <div className="metric-grid">
      <MetricCard label="Meals saved" value="184" detail="+ 22 from last week" trend="up" icon={CircleCheck} tone="mint" />
      <MetricCard label="Waste avoided" value="126.4" suffix=" kg" detail="+ 18.6 kg from last week" trend="up" icon={RefreshCw} tone="sun" />
      <MetricCard label="CO₂ prevented" value="211.8" suffix=" kg" detail="Equivalent to 864 km by car" icon={Leaf} tone="navy" />
      <MetricCard label="Handoffs completed" value="23" detail="4 partners in rotation" icon={Handshake} tone="coral" />
    </div>
    <div className="dashboard-grid">
      <section className="surface-card surplus-card"><div className="card-heading"><div><div className="eyebrow">Needs a decision</div><h2 className="card-title">Active surplus</h2></div><span className="count-badge">3 items</span></div><div className="surplus-list">{active.map(item => <div className={`surplus-row ${acknowledged.includes(item.id) ? 'acknowledged' : ''}`} key={item.id} data-testid={`row-surplus-${item.id}`}><div className="food-swatch">{item.name.slice(0, 1)}</div><div className="surplus-info"><strong>{item.name}</strong><span>{item.source}</span></div><div className="age"><Clock3 size={13} />{item.age}</div><span className={`decision-pill ${item.tone}`}>{item.status}</span><button className="icon-button" onClick={() => setAcknowledged([...acknowledged, item.id])} aria-label={`Acknowledge ${item.name}`} disabled={acknowledged.includes(item.id)} data-testid={`button-acknowledge-${item.id}`}>{acknowledged.includes(item.id) ? <Check size={15} /> : <ChevronRight size={16} />}</button></div>)}</div><Link href="/assistant" className="card-footer-link" data-testid="link-review-all-surplus">Review all surplus <ArrowUpRight size={14} /></Link></section>
      <section className="surface-card pulse-card"><div className="card-heading"><div><div className="eyebrow">Signal</div><h2 className="card-title">Rescue pulse</h2></div><span className="live-label"><span className="status-pulse" />LIVE</span></div><div className="mini-chart"><div className="chart-y"><span>80</span><span>40</span><span>0</span></div><div className="chart-bars">{[35, 48, 41, 61, 74, 66, 52, 68, 84, 72, 91, 78].map((height, i) => <div className="bar-wrap" key={i}><div className={`bar ${i > 8 ? 'bar-hot' : ''}`} style={{ height: `${height}%` }} /></div>)}</div></div><div className="pulse-caption"><span><strong>+18%</strong> rescue rate</span><span className="mono">LAST 12 HANDOFFS</span></div></section>
    </div>
    <section className="notice-strip"><Info size={18} /><div><strong>Designed for the handoff moment.</strong><span>All recommendations are local, deterministic examples until your team connects a policy source and partner directory.</span></div><Link href="/methodology" data-testid="link-learn-methodology">See how it works <ChevronRight size={15} /></Link></section>
  </div>;
}

function Assistant() {
  const [form, setForm] = useState({ food: assessmentSeed.food, quantityKg: String(assessmentSeed.quantityKg), preparedAt: assessmentSeed.preparedAt, storage: assessmentSeed.storage, currentTime: assessmentSeed.currentTime });
  const [result, setResult] = useState(assessmentSeed);
  const [running, setRunning] = useState(false);
  const runAssessment = () => { setRunning(true); window.setTimeout(() => { const older = form.storage.toLowerCase().includes('room'); setResult({ ...assessmentSeed, food: form.food, quantityKg: Number(form.quantityKg) || 0, preparedAt: form.preparedAt, storage: form.storage, currentTime: form.currentTime, decision: older ? 'Review' : 'Donate', confidence: older ? 68 : 92, urgency: older ? 'Resolve within 45 minutes' : 'Collect within 2 hours', reason: older ? 'The storage detail suggests the item may have spent time above the cold-hold threshold. Confirm the time window before handoff.' : assessmentSeed.reason }); setRunning(false); }, 450); };
  const setField = (key: keyof typeof form, value: string) => setForm(prev => ({ ...prev, [key]: value }));
  return <div className="page-enter"><PageHeader eyebrow="Safety assistant / local review" title="Is this safe to share?" description="A focused, evidence-aware review for the five minutes between kitchen close and community pickup." action={<span className="local-chip"><Database size={14} /> Local deterministic mode</span>} />
    <div className="assistant-grid"><section className="surface-card form-card"><div className="card-heading"><div><h2 className="card-title">Surplus details</h2><p className="card-subtitle">Edit the facts, then run a fresh review.</p></div><SlidersHorizontal size={18} className="muted-icon" /></div><label>Food or dish<input value={form.food} onChange={e => setField('food', e.target.value)} data-testid="input-food" /></label><div className="form-two"><label>Quantity<input type="number" value={form.quantityKg} onChange={e => setField('quantityKg', e.target.value)} data-testid="input-quantity" /><span className="input-suffix">kg</span></label><label>Storage<select value={form.storage} onChange={e => setField('storage', e.target.value)} data-testid="select-storage"><option>Refrigerated at 3°C</option><option>Refrigerated at 5°C</option><option>Held at room temperature</option><option>Frozen at -18°C</option></select></label></div><label>Prepared at<input type="datetime-local" value={form.preparedAt} onChange={e => setField('preparedAt', e.target.value)} data-testid="input-prepared-at" /></label><label>Current review time<input type="datetime-local" value={form.currentTime} onChange={e => setField('currentTime', e.target.value)} data-testid="input-current-time" /></label><button className="primary-button full-button" onClick={runAssessment} disabled={running} data-testid="button-run-assessment">{running ? <><RefreshCw size={16} className="spin" /> Reviewing evidence…</> : <><Sparkles size={16} /> Run safety review</>}</button><div className="form-footnote"><ShieldCheck size={14} />No health decision is made without staff verification.</div></section>
      <section className="surface-card assessment-card"><div className="card-heading"><div><div className="eyebrow">Assessment output</div><h2 className="card-title">Decision at a glance</h2></div><span className="mono result-time">RUN 15:10</span></div><div className={`decision-banner ${result.decision === 'Donate' ? 'decision-donate' : 'decision-review'}`}><div className="decision-icon">{result.decision === 'Donate' ? <CircleCheck size={25} /> : <TriangleAlert size={25} />}</div><div><span className="decision-kicker">Recommended path</span><strong data-testid="text-assessment-decision">{result.decision}</strong><p>{result.reason}</p></div></div><div className="confidence-row"><div><span>Confidence</span><strong>{result.confidence}%</strong></div><div className="confidence-track"><div className="confidence-fill" style={{ width: `${result.confidence}%` }} /></div></div><div className="urgency-box"><Clock3 size={18} /><div><span>Timing matters</span><strong>{result.urgency}</strong></div></div><div className="evidence-block"><div className="evidence-head"><span><Search size={15} /> Retrieved sources</span><span className="mono">{result.sources.length} MATCHES</span></div>{result.sources.map((source, i) => <div className="source-snippet" key={source}><span className="source-number">0{i + 1}</span><p>{source}</p><ExternalLink size={14} /></div>)}</div></section></div>
  </div>;
}

function SimpleLineChart({ rows }: { rows: ForecastRow[] }) {
  const max = Math.max(...rows.map(r => Math.max(r.actualKg, r.expectedKg))) + 10;
  const point = (value: number, index: number) => `${(index / (rows.length - 1)) * 100},${100 - (value / max) * 86 - 5}`;
  return <div className="trend-chart"><div className="chart-labels"><span>{max} kg</span><span>{Math.round(max / 2)} kg</span><span>0 kg</span></div><svg viewBox="0 0 100 100" preserveAspectRatio="none" role="img" aria-label="Historical surplus trend"><defs><linearGradient id="trendFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="hsl(40 96% 63% / .3)" /><stop offset="1" stopColor="hsl(40 96% 63% / 0)" /></linearGradient></defs><path d={`M ${point(rows[0].actualKg, 0)} ${rows.map((r, i) => `L ${point(r.actualKg, i)}`).join(' ')} L 100,100 L 0,100 Z`} fill="url(#trendFill)" /><polyline points={rows.map((r, i) => point(r.expectedKg, i)).join(' ')} fill="none" stroke="hsl(163 45% 36%)" strokeWidth=".8" strokeDasharray="2 2" /><polyline points={rows.map((r, i) => point(r.actualKg, i)).join(' ')} fill="none" stroke="hsl(231 32% 17%)" strokeWidth="1.5" />{rows.map((r, i) => <circle key={r.date} cx={point(r.actualKg, i).split(',')[0]} cy={point(r.actualKg, i).split(',')[1]} r="1.5" fill="hsl(40 96% 63%)" stroke="hsl(231 32% 17%)" strokeWidth=".7" />)}</svg><div className="chart-x">{rows.map(r => <span key={r.date}>{r.date}</span>)}</div></div>;
}

function Forecast() {
  const [range, setRange] = useState('7 days');
  const [selected, setSelected] = useState('Shift the Friday prep');
  const interventions = [{ title: 'Shift the Friday prep', detail: 'Move 8 portions of tagine to Saturday lunch based on the last 4 weeks.', impact: '−12.4 kg expected surplus', icon: CalendarDays }, { title: 'Open a second pickup window', detail: 'East Bay Food Collective has capacity between 18:00 and 19:00.', impact: '+19 meals rescued', icon: Handshake }, { title: 'Flag the bakery close', detail: 'Friday pastries are the most consistent preventable surplus signal.', impact: '−8.2 kg landfill', icon: TrendingUp }];
  return <div className="page-enter"><PageHeader eyebrow="Surplus forecast / Oakland kitchen" title="See the surplus before it lands." description="A lightweight planning view built from your recent handoffs, not a black box." action={<div className="range-toggle">{['7 days', '30 days'].map(item => <button className={range === item ? 'active' : ''} onClick={() => setRange(item)} key={item} data-testid={`button-range-${item.replace(' ', '-')}`}>{item}</button>)}</div>} />
    <div className="metric-grid forecast-metrics"><MetricCard label="Next 7 days" value="392" suffix=" kg" detail="Expected surplus" icon={ChartNoAxesCombined} tone="sun" /><MetricCard label="Likely rescued" value="281" suffix=" kg" detail="Based on current partner capacity" trend="up" icon={CircleCheck} tone="mint" /><MetricCard label="At-risk window" value="Fri 17:00" detail="Peak surplus signal" icon={Clock3} tone="coral" /></div>
    <div className="forecast-grid"><section className="surface-card chart-card"><div className="card-heading"><div><div className="eyebrow">Historical pattern · {range}</div><h2 className="card-title">Surplus volume</h2></div><div className="legend"><span><i className="legend-dot actual" />Actual</span><span><i className="legend-line" />Expected</span></div></div><SimpleLineChart rows={forecastSeed} /><div className="chart-insight"><Sparkles size={16} /><span><strong>Friday is your signal.</strong> Actual surplus runs 14% above the weekly baseline when bakery and service close together.</span></div></section>
      <section className="surface-card intervention-card"><div className="card-heading"><div><div className="eyebrow">Recommended moves</div><h2 className="card-title">Small changes, earlier</h2></div><span className="count-badge">3 signals</span></div><div className="intervention-list">{interventions.map((item, i) => <button className={`intervention ${selected === item.title ? 'selected' : ''}`} onClick={() => setSelected(item.title)} key={item.title} data-testid={`button-intervention-${i}`}><IconBadge icon={item.icon} tone={i === 0 ? 'sun' : i === 1 ? 'mint' : 'coral'} /><span><strong>{item.title}</strong><small>{item.detail}</small><em>{item.impact}</em></span><ChevronRight size={16} /></button>)}</div><div className="selected-note"><Check size={15} /> Planning focus: <strong>{selected}</strong></div></section></div>
    <section className="surface-card forecast-table-card"><div className="card-heading"><div><div className="eyebrow">Forecast log</div><h2 className="card-title">Expected versus actual</h2></div><span className="mono">KG / DAY</span></div><div className="table-scroll"><table><thead><tr><th>Date</th><th>Expected</th><th>Actual</th><th>Prevented</th><th>Variance</th></tr></thead><tbody>{forecastSeed.map(row => <tr key={row.date}><td><strong>{row.date}</strong></td><td>{row.expectedKg}</td><td>{row.actualKg}</td><td className="mint-text">{row.preventedKg}</td><td><span className={row.actualKg > row.expectedKg ? 'variance-up' : 'variance-down'}>{row.actualKg > row.expectedKg ? '+' : ''}{row.actualKg - row.expectedKg} kg</span></td></tr>)}</tbody></table></div></section>
  </div>;
}

function Partners() {
  const [city, setCity] = useState('Oakland');
  const [kind, setKind] = useState('All food types');
  const [contacted, setContacted] = useState<string | null>(null);
  const filtered = partnersSeed.filter(p => (city === 'All cities' || p.city === city) && (kind === 'All food types' || p.accepts.includes(kind)));
  const contactPartner = (name: string) => { setContacted(name); window.setTimeout(() => setContacted(null), 2600); };
  return <div className="page-enter"><PageHeader eyebrow="Community partners / live directory" title="Find the next good home." description="City-aware recommendations ranked for food type, distance and today’s pickup capacity." action={<span className="local-chip"><MapPin size={14} /> Oakland, CA</span>} />
    <section className="partner-tools surface-card"><div className="search-field"><Search size={17} /><input placeholder="Search by partner or neighborhood" aria-label="Search partners" data-testid="input-search-partners" /></div><select value={city} onChange={e => setCity(e.target.value)} data-testid="select-city"><option>Oakland</option><option>Berkeley</option><option>All cities</option></select><select value={kind} onChange={e => setKind(e.target.value)} data-testid="select-food-type"><option>All food types</option><option>Prepared meals</option><option>Produce</option><option>Bakery</option><option>Dairy</option></select><button className="filter-button" data-testid="button-more-filters"><SlidersHorizontal size={16} /> More filters</button></section>
    <div className="partner-context"><span><strong>{filtered.length}</strong> nearby matches</span><span className="context-rule" /><span>Sorted by pickup fit <ChevronDown size={14} /></span></div>
    <div className="partner-list">{filtered.map((partner, i) => <article className="surface-card partner-card" key={partner.name} data-testid={`card-partner-${i}`}><div className="partner-rank">{String(i + 1).padStart(2, '0')}</div><div className="partner-main"><div className="partner-title-row"><div><h2>{partner.name}</h2><div className="partner-meta"><MapPin size={14} />{partner.city} · {partner.distanceKm} km away</div></div><span className={`partner-status ${partner.status.includes('Limited') ? 'limited' : ''}`}><span />{partner.status}</span></div><div className="accepts">{partner.accepts.map(a => <span key={a}>{a}</span>)}</div><div className="partner-bottom"><span><Clock3 size={14} />{partner.hours}</span><span className="partner-contact">{partner.contact}</span><div className="partner-actions"><button className="secondary-button" onClick={() => contactPartner(partner.name)} data-testid={`button-contact-${i}`}><Send size={14} /> {contacted === partner.name ? 'Request sent' : 'Request pickup'}</button><button className="icon-button bordered" aria-label={`Call ${partner.name}`} data-testid={`button-call-${i}`}><Phone size={15} /></button></div></div></div></article>)}</div>
    {filtered.length === 0 && <div className="empty-state surface-card"><Handshake size={28} /><h2>No matching partners yet</h2><p>Try widening the city or food type filter. The local directory is intentionally small and reviewable.</p><button className="secondary-button" onClick={() => { setCity('All cities'); setKind('All food types'); }} data-testid="button-reset-partners">Reset filters</button></div>}
  </div>;
}

function Impact() {
  const [inputs, setInputs] = useState({ mealsSaved: 184, wasteReducedKg: 126.4, co2SavedKg: 211.8, landfillReducedKg: 84.3 });
  const impact: Impact = useMemo(() => ({ mealsSaved: Number(inputs.mealsSaved) || 0, wasteReducedKg: Number(inputs.wasteReducedKg) || 0, co2SavedKg: Number(inputs.co2SavedKg) || 0, landfillReducedKg: Number(inputs.landfillReducedKg) || 0 }), [inputs]);
  const setValue = (key: keyof Impact, value: string) => setInputs(prev => ({ ...prev, [key]: Number(value) }));
  const max = Math.max(impact.wasteReducedKg, impact.co2SavedKg, impact.landfillReducedKg);
  const bars = [{ label: 'Food waste', value: impact.wasteReducedKg, color: 'sun' }, { label: 'CO₂ equivalent', value: impact.co2SavedKg, color: 'navy' }, { label: 'Landfill avoided', value: impact.landfillReducedKg, color: 'mint' }];
  return <div className="page-enter"><PageHeader eyebrow="Impact ledger / scenario calculator" title="Make the invisible count." description="Translate every rescued kilogram into a story your team, partners and reviewers can stand behind." action={<span className="local-chip"><Calculator size={14} /> Editable scenario</span>} />
    <div className="impact-grid"><section className="surface-card impact-inputs"><div className="card-heading"><div><div className="eyebrow">Scenario inputs</div><h2 className="card-title">What changed?</h2></div><button className="text-button" onClick={() => setInputs({ mealsSaved: 184, wasteReducedKg: 126.4, co2SavedKg: 211.8, landfillReducedKg: 84.3 })} data-testid="button-reset-impact"><RefreshCw size={14} /> Reset</button></div><p className="card-subtitle">Use your verified handoff totals or explore a future week.</p>{([{ key: 'mealsSaved', label: 'Meals saved', unit: 'meals' }, { key: 'wasteReducedKg', label: 'Waste reduced', unit: 'kg' }, { key: 'co2SavedKg', label: 'CO₂ saved', unit: 'kg' }, { key: 'landfillReducedKg', label: 'Landfill avoided', unit: 'kg' }] as { key: keyof Impact; label: string; unit: string }[]).map(item => <label className="impact-input" key={item.key}><span>{item.label}<small>{item.unit}</small></span><input type="number" step="0.1" value={inputs[item.key]} onChange={e => setValue(item.key, e.target.value)} data-testid={`input-impact-${item.key}`} /></label>)}<div className="formula-note"><Info size={15} /><span>Estimates use a transparent local factor set: 1 meal = 0.69 kg food rescued; 1 kg rescued = 1.68 kg CO₂e avoided.</span></div></section><section className="surface-card impact-output"><div className="eyebrow">Current scenario</div><div className="impact-big-number"><span>{impact.mealsSaved}</span><small>meals saved</small></div><div className="impact-bars">{bars.map(bar => <div className="impact-bar-row" key={bar.label}><div><span>{bar.label}</span><strong>{bar.value.toFixed(1)} kg</strong></div><div className="impact-track"><div className={`impact-fill ${bar.color}`} style={{ width: `${Math.max(5, (bar.value / max) * 100)}%` }} /></div></div>)}</div><div className="equivalence"><Leaf size={18} /><div><span>In everyday terms</span><strong>Your surplus avoided roughly {Math.round(impact.co2SavedKg / 0.21)} km of car travel.</strong></div></div></section></div>
    <section className="impact-foot"><div><div className="eyebrow">The ledger is a conversation</div><h2 className="display section-title">Show the work, not just the number.</h2></div><p>Every estimate stays editable, sourced and easy to explain in a handoff report. That is how trust compounds across a kitchen, a food bank and an internship review.</p><Link href="/reports" className="secondary-button" data-testid="link-impact-report">Open impact report <ArrowUpRight size={15} /></Link></section>
  </div>;
}

function downloadFile(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = filename; link.click(); URL.revokeObjectURL(url);
}

function Reports() {
  const [downloaded, setDownloaded] = useState<string | null>(null);
  const download = (kind: 'csv' | 'pdf') => { if (kind === 'csv') downloadFile('food-rescue-impact-feb-2025.csv', 'metric,value,unit\\nmeals_saved,184,meals\\nwaste_reduced,126.4,kg\\nco2_saved,211.8,kg\\nlandfill_reduced,84.3,kg\\n', 'text/csv'); else downloadFile('food-rescue-summary-feb-2025.pdf', 'FOOD RESCUE AI\\nDonation summary — February 2025\\n\\n184 meals saved\\n126.4 kg waste avoided\\n211.8 kg CO2e prevented\\n\\nPrepared in local mode for review.', 'application/pdf'); setDownloaded(kind); window.setTimeout(() => setDownloaded(null), 2300); };
  return <div className="page-enter"><PageHeader eyebrow="Reports / ready to share" title="A clean record of the good work." description="Package your handoffs, assumptions and learning into something a partner or reviewer can use." action={<span className="local-chip"><FileText size={14} /> February 2025</span>} />
    <section className="report-hero surface-card"><div className="report-hero-copy"><div className="eyebrow warm">Donation summary</div><h2 className="display report-title">The month in<br /><em>community value.</em></h2><p>23 completed handoffs across 4 local partners, with 92% of assessed food cleared for donation.</p><div className="report-actions"><button className="primary-button" onClick={() => download('pdf')} data-testid="button-download-pdf"><Download size={16} /> {downloaded === 'pdf' ? 'PDF saved' : 'Download PDF-style summary'}</button><button className="secondary-button" onClick={() => download('csv')} data-testid="button-download-csv"><FileSpreadsheet size={16} /> {downloaded === 'csv' ? 'CSV saved' : 'Export CSV'}</button></div></div><div className="report-stamp"><span>FR</span><strong>02</strong><small>2025</small><div /></div></section>
    <div className="report-grid"><section className="surface-card summary-card"><div className="card-heading"><div><div className="eyebrow">At a glance</div><h2 className="card-title">Verified totals</h2></div><CircleCheck size={19} className="mint-icon" /></div><div className="summary-list"><div><span>Meals saved</span><strong>184</strong><small>+13% vs Jan</small></div><div><span>Waste reduced</span><strong>126.4 kg</strong><small>Across 23 handoffs</small></div><div><span>CO₂ prevented</span><strong>211.8 kg</strong><small>Method factor v1.2</small></div><div><span>Top partner</span><strong>Northside Pantry</strong><small>9 completed pickups</small></div></div></section><section className="surface-card materials-card"><div className="card-heading"><div><div className="eyebrow">Submission-ready materials</div><h2 className="card-title">Bring the project with you</h2></div><Presentation size={19} className="muted-icon" /></div><div className="resource-list">{resources.slice(0, 3).map((resource, i) => <a href={resource.href} className="resource-row" key={resource.title} data-testid={`link-resource-${i}`}><div className="resource-icon"><FileText size={16} /></div><div><strong>{resource.title}</strong><span>{resource.description}</span></div><span className="resource-type">{resource.type}</span><ArrowUpRight size={15} /></a>)}</div></section></div>
    <section className="no-api-banner"><Database size={19} /><div><strong>When your API is ready, this report is ready too.</strong><span>Connect a verified partner directory and policy source to replace local examples without changing the review flow.</span></div><Link href="/methodology" className="text-link" data-testid="link-api-methodology">Read integration notes <ChevronRight size={15} /></Link></section>
  </div>;
}

function Methodology() {
  const [tab, setTab] = useState('workflow');
  const tabs = [{ id: 'workflow', label: 'RAG workflow', icon: BrainCircuit }, { id: 'architecture', label: 'Architecture', icon: Database }, { id: 'responsible', label: 'Responsible AI', icon: ShieldCheck }, { id: 'presentation', label: '12-slide outline', icon: FileText }];
  const slides = ['The problem: good food meets a bad clock', 'A kitchen lead’s five-minute decision', 'What Food Rescue AI changes', 'The signal: surplus before disposal', 'Safety assistant: facts before confidence', 'Evidence retrieval and source snippets', 'Forecasting the next high-risk window', 'A partner match built for today', 'Impact ledger: from kg to community value', 'Responsible AI guardrails', 'Prototype learnings and next build', 'The invitation: make rescue routine'];
  return <div className="page-enter"><PageHeader eyebrow="Methodology / internship documentation" title="Show your thinking." description="A plain-language record of the workflow, architecture and guardrails behind this prototype." action={<span className="local-chip"><BookOpen size={14} /> Project notebook</span>} /><div className="method-tabs">{tabs.map(({ id, label, icon: Icon }) => <button className={tab === id ? 'active' : ''} onClick={() => setTab(id)} key={id} data-testid={`button-method-${id}`}><Icon size={16} />{label}</button>)}</div>
    {tab === 'workflow' && <div className="method-grid"><section className="surface-card workflow-card"><div className="eyebrow">Retrieval augmented generation</div><h2 className="card-title">Evidence first. Answer second.</h2><div className="workflow-steps">{[['01', 'Capture context', 'Food, time, storage and quantity become structured facts.'], ['02', 'Retrieve policy', 'The assistant finds relevant food-safety guidance and partner constraints.'], ['03', 'Ground the answer', 'Source snippets sit beside confidence, urgency and the recommended path.'], ['04', 'Keep a human in the loop', 'Staff verify the handoff; the system never silently decides for them.']].map(([n, title, text]) => <div className="workflow-step" key={n}><span>{n}</span><div><strong>{title}</strong><p>{text}</p></div></div>)}</div></section><section className="surface-card principles-card"><div className="eyebrow">Design principles</div><div className="principle"><span>01</span><strong>Readable under pressure</strong><p>Every decision has a reason, a clock and a next action.</p></div><div className="principle"><span>02</span><strong>Auditable by default</strong><p>Retrieved snippets and local factors make review possible.</p></div><div className="principle"><span>03</span><strong>Small enough to trust</strong><p>No hidden automation. Every control has a clear owner.</p></div></section></div>}
     {tab === 'architecture' && <div className="surface-card architecture-card"><div className="eyebrow">Prototype architecture</div><h2 className="card-title">Four layers, one calm handoff.</h2><div className="architecture-flow">{[['01', 'Interface', 'React + local deterministic state', 'Kitchen-ready screens'], ['02', 'Decision layer', 'Rules + retrieval orchestration', 'Safety, forecast, match'], ['03', 'Evidence', 'Policy docs + partner directory', 'Citations and constraints'], ['04', 'Learning loop', 'Handoff outcomes + review notes', 'Better signals over time']].map(([n, title, tech, detail], i) => <div className="architecture-node" key={n}><span className="node-number">{n}</span><div><strong>{title}</strong><span>{tech}</span><small>{detail}</small></div>{i < 3 && <ChevronRight className="node-arrow" size={18} />}</div>)}</div><div className="architecture-note"><Info size={16} /><span>This first build deliberately keeps the API boundary visible. Replace local arrays with a policy retriever, forecast service and partner directory when validated.</span></div></div>}
    {tab === 'responsible' && <div className="method-grid"><section className="surface-card responsible-card"><div className="eyebrow">Responsible AI checklist</div><h2 className="card-title">Helpful without overclaiming.</h2>{['Citations are visible at the point of decision.', 'Confidence is not a safety guarantee.', 'Urgency is explicit, never hidden in color alone.', 'Staff can edit every input before re-running.', 'Local mode explains exactly what is not connected.'].map((item, i) => <div className="check-row" key={item}><span><Check size={14} /></span><strong>{item}</strong><small>PASS · review {i + 1}</small></div>)}</section><section className="surface-card responsible-note"><TriangleAlert size={22} /><h2>Known limits</h2><p>This prototype uses representative policy snippets and a fixed Oakland partner set. It should support a trained staff member, not replace food-safety certification or a real-time availability call.</p><button className="secondary-button" onClick={() => setTab('architecture')} data-testid="button-view-boundary">View system boundary <ArrowUpRight size={15} /></button></section></div>}
    {tab === 'presentation' && <section className="surface-card slides-card"><div className="card-heading"><div><div className="eyebrow">Presentation outline</div><h2 className="card-title">12 slides, one clear story.</h2></div><span className="mono">12 / 12</span></div><div className="slides-list">{slides.map((slide, i) => <div className="slide-row" key={slide}><span>{String(i + 1).padStart(2, '0')}</span><strong>{slide}</strong><ChevronRight size={15} /></div>)}</div><button className="primary-button" onClick={() => downloadFile('food-rescue-presentation-outline.txt', slides.map((slide, i) => `${i + 1}. ${slide}`).join('\\n'), 'text/plain')} data-testid="button-download-outline"><Download size={16} /> Download outline</button></section>}
  </div>;
}

function NotFound() {
  return <div className="empty-state surface-card"><TriangleAlert size={30} /><div className="eyebrow">404 / route not found</div><h1 className="display section-title">That handoff missed.</h1><p>Return to the command center and pick up where you left off.</p><Link href="/" className="primary-button" data-testid="link-return-home">Return to command center</Link></div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <Shell><RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route path="/assistant" component={Assistant} /><Route path="/forecast" component={Forecast} /><Route path="/partners" component={Partners} /><Route path="/impact" component={Impact} /><Route path="/reports" component={Reports} /><Route path="/methodology" component={Methodology} /><Route component={NotFound} /></Switch></RoutedErrorBoundary></Shell>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;