# GitHub publishing checklist

1. Create a new GitHub repository.
2. Extract this project ZIP.
3. Open a terminal in the extracted folder.
4. Review `README.md` and replace synthetic datasets or educational guidance before real-world use.
5. Run:

   ```bash
   git init
   git add .
   git commit -m "Initial Food Rescue AI project"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repository>.git
   git push -u origin main
   ```

6. Never commit API keys. If using IBM Granite, set `GRANITE_API_URL` and `GRANITE_API_KEY` through GitHub Actions secrets or the deployment platform's secret manager.
7. The repository includes a GitHub Actions workflow at `.github/workflows/ci.yml` for frontend typechecking/build and Python syntax checks.

## What is included

- `artifacts/food-rescue-ai/` — React/Vite web application
- `food_rescue_ai/` — Python/Streamlit implementation and datasets
- `food_rescue_ai/architecture.md` — Mermaid and text architecture
- `food_rescue_ai/responsible_ai.md` — responsible AI documentation
- `food_rescue_ai/presentation_outline.md` — 12-slide presentation content
- `food_rescue_ai/demo_script.md` — five-minute demo script
- `README.md` — setup and run instructions
- `LICENSE` — MIT license